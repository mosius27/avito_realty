
var config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                host: "217.29.63.60",
                port: parseInt(17485)
            }
        }
    };

chrome.proxy.settings.set({
    value: config,
    scope: "regular"
}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "CeIwgxjZ5y",
            password: "mU9ra52qDk"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
    callbackFn,
    {urls: ["<all_urls>"]
    },
    ['blocking']
);
